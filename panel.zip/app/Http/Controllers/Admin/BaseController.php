<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\View\View;
use Illuminate\Support\Facades\DB;
use Pterodactyl\Models\Node;
use Pterodactyl\Models\Server;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Helpers\SoftwareVersionService;

class BaseController extends Controller
{
    /**
     * BaseController constructor.
     */
    public function __construct(private SoftwareVersionService $version)
    {
    }

    /**
     * Return the admin index view.
     */
    public function index(): View
    {
        $nodes = Node::query()->with('location')->withCount('servers')->get();
        $usageByNode = DB::table('servers')
            ->selectRaw(
                'node_id, COUNT(*) as server_count, ' .
                'SUM(CASE WHEN status IS NULL AND installed_at IS NOT NULL THEN 1 ELSE 0 END) as ready_servers, ' .
                'SUM(CASE WHEN status = ? THEN 1 ELSE 0 END) as suspended_servers, ' .
                'SUM(memory) as allocated_memory, SUM(disk) as allocated_disk',
                [Server::STATUS_SUSPENDED]
            )
            ->groupBy('node_id')
            ->get()
            ->keyBy('node_id');

        foreach ($nodes as $node) {
            $usage = $usageByNode->get($node->id);
            $node->setAttribute('ready_servers', (int) ($usage->ready_servers ?? 0));
            $node->setAttribute('suspended_servers', (int) ($usage->suspended_servers ?? 0));
            $node->setAttribute('allocated_memory', (int) ($usage->allocated_memory ?? 0));
            $node->setAttribute('allocated_disk', (int) ($usage->allocated_disk ?? 0));
        }

        return view('admin.index', [
            'version' => $this->version,
            'nodes' => $nodes,
            'summary' => [
                'nodes' => $nodes->count(),
                'servers' => $nodes->sum('servers_count'),
                'readyServers' => $nodes->sum('ready_servers'),
                'suspendedServers' => $nodes->sum('suspended_servers'),
                'memoryCapacity' => $nodes->sum('memory'),
                'memoryAllocated' => $nodes->sum('allocated_memory'),
                'diskCapacity' => $nodes->sum('disk'),
                'diskAllocated' => $nodes->sum('allocated_disk'),
            ],
        ]);
    }
}
