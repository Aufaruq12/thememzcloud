<?php

namespace Pterodactyl\Http\ViewComposers;

use Illuminate\View\View;
use Pterodactyl\Services\Helpers\AssetHashService;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;

class AssetComposer
{
    /**
     * AssetComposer constructor.
     */
    public function __construct(
        private AssetHashService $assetHashService,
        private SettingsRepositoryInterface $settings,
    ) {
    }

    /**
     * Provide access to the asset service in the views.
     */
    public function compose(View $view): void
    {
        $view->with('asset', $this->assetHashService);
        $view->with('siteConfiguration', [
            'name' => config('app.name') ?? 'Pterodactyl',
            'locale' => config('app.locale') ?? 'en',
            'recaptcha' => [
                'enabled' => config('recaptcha.enabled', false),
                'siteKey' => config('recaptcha.website_key') ?? '',
            ],
            'theme' => [
                'pageColor' => $this->settings->get('mzcloud:theme:page_color', '#101019'),
                'sidebarColor' => $this->settings->get('mzcloud:theme:sidebar_color', '#171622'),
                'accentColor' => $this->settings->get('mzcloud:theme:accent_color', '#32c2d0'),
                'logoUrl' => $this->settings->get('mzcloud:theme:logo_url', ''),
                'footer' => $this->settings->get('mzcloud:theme:footer', ''),
            ],
        ]);
    }
}
